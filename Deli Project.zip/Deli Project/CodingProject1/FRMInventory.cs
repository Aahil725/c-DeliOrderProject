﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodingProject1
{
    public partial class FRMInventory : Form
    {
        public FRMInventory()
        {
            InitializeComponent();
        }

        private decimal[] UpdatedInventory; // empty array to continously update throughout user entries
        private string[] UpdatedFoodItems; //  empty array to continously update throughout user entries


        public decimal[] ArrayUpdatedInventory // setter/getter methods
        {
            get
            {
                return UpdatedInventory;
            }
            set
            {
                UpdatedInventory = value; 
            }
        }

        public string[] UpdatedInventoryFoodItems // setter/getter methods
        {
            get
            {
                return UpdatedFoodItems;
            }
            set
            {
                UpdatedFoodItems = value; 
            }
        }

        /// <summary>
        /// loads into the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void FRMInventory_Load(object sender, EventArgs e)
        {
            LoadInventoryListbox();
        }

        /// <summary>
        /// loads the ingredients and its quantity into listbox
        /// </summary>
        public void LoadInventoryListbox()
        {
            LBXInventory.Items.Clear();
            for (int i = 0; i < UpdatedInventory.Length; i++)
            {
                LBXInventory.Items.Add(UpdatedFoodItems[i] + ": " + UpdatedInventory[i]); // loads initial items and quantities into listbox
            }
        }

        /// <summary>
        /// when esc or exit is clicked, close the form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}