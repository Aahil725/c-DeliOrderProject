﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodingProject1
{
    public static class Validator
    {
        // all the different validation methods

        /// <summary>
        /// Validates whether a food item and bread/crust type are selected.
        /// </summary>
        /// <returns></returns>
        public static string IsSelected(int intSelectedIndex)
        {
            string strMessage = "";

            if (intSelectedIndex == 0)
            {
                strMessage += "Please choose a product." + "\n";
            }
            else if (intSelectedIndex == 0)
            {
                strMessage += "Please choose a bread/crust type." + "\n";
            }

            return strMessage;
        }

        /// <summary>
        ///  Validates the quantity input to ensure it is not empty, is a whole number, and is greater than zero.
        /// </summary>
        /// <returns></returns>
        public static string IsValidQuantity(string strQuantity)
        {
            string strMessage = "";

            if (strQuantity == "") //if quantity is empty
            {
                strMessage = "Item quantity must be entered." + "\n";
            }
            else if (!Int32.TryParse(strQuantity, out Int32 intQuantity)) //integer validation
            {
                strMessage = "Quantity must be a whole number." + "\n";
            }
            else if (intQuantity <= 0) // cant be 0 or negative
            {
                strMessage = "Quantity must be greater than zero." + "\n";
            }

            return strMessage;
        }

        /// <summary>
        /// if the user inputted all of customer requirements
        /// </summary>
        /// <returns></returns>
        public static string IsPresentOrder(string strCustomerName, string strCustomerStreet, string strCustomerCity, string strCustomerState, string strCustomerZip, string strCustomerPhone, string strCustomerSubdivision)
        {
            string strMessage = "";

            if (string.IsNullOrWhiteSpace(strCustomerName) ||
                string.IsNullOrWhiteSpace(strCustomerStreet) ||
                string.IsNullOrWhiteSpace(strCustomerCity) ||
                string.IsNullOrWhiteSpace(strCustomerState) ||
                string.IsNullOrWhiteSpace(strCustomerZip) ||
                string.IsNullOrWhiteSpace(strCustomerPhone)) // Subdivision can be empty
            {
                strMessage = "Please fill out all required customer information." + "\n";
            }

            return strMessage;
        }


        /// <summary>
        /// Validates whether at least one item is added to the order.
        /// </summary>
        /// <returns></returns>
        public static string IsValidOrder(int intItemsCount)
        {
            string strMessage = "";
            if (intItemsCount == 0) //if list box is empty
            {
                strMessage = "Please order at least one item." + "\n";

            }
            return strMessage;

        }

        /// <summary>
        /// Validates that the delivery address is in Bryan, TX or College Station, TX.
        /// </summary>
        /// <param name="strDeliveryCity"></param>
        /// <returns></returns>
        public static string IsValidCity(string strDeliveryCity, string strDeliveryState, bool blnCarryoutChecked, bool blnDeliveryChecked)
        {
            string strMessage = "";

            strDeliveryCity = strDeliveryCity.Trim();
            strDeliveryCity = strDeliveryCity.ToLower();
            strDeliveryState = strDeliveryState.Trim();
            strDeliveryState = strDeliveryState.ToLower();

            if (blnCarryoutChecked == true)
            {
                strMessage = "";
            }
            else if (blnDeliveryChecked == true && strDeliveryCity != "bryan" && strDeliveryCity != "college station") //if the text isnt either bryan or college station
            {
                strMessage = "Delivery address must be in Bryan, TX or College Station, TX." + "\n";
            }
            else if (strDeliveryState != "tx" && strDeliveryState != "texas") //if the text isnt either tx or texas
            {
                strMessage = "Delivery address must be in Bryan, TX or College Station, TX." + "\n";
            }

            return strMessage;
        }


        /// <summary>
        /// makes sure each field is present for the vendor form
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns>
        public static string IsPresentVendor(string strTestValue, string strControlName)
        {
            string strMessage = ""; // sets variable
            if (strTestValue.Trim() == "")
            {
                strMessage = strControlName + " is a required field.\n"; //message output
            }
            return strMessage;
        }

        /// <summary>
        /// makes sure the fields only contain integers
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strControlName"></param>
        /// <returns></returns>
        public static string IsInteger(string strTestValue, string strControlName)
        {
            string strMessage = ""; //sets variable
            if (!Int32.TryParse(strTestValue, out _))
            {
                strMessage = strControlName + " must contain integers only.\n"; //message output
            }
            return strMessage;
        }


    }
}
