﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

namespace CodingProject1
{
    public partial class FRMOrder : Form
    {

        public FRMOrder()
        {
            InitializeComponent();
        }

        // Arrays for food items, bread types, crust types, and a placeholder for no selection.

        string[] strFoodItems = {"Choose a food item", // food item array
                                "Ham & Swiss sandwich",
                                "Turkey & Provolone sandwich",
                                "BLT sandwich",
                                "Med. Cheese pizza",
                                "Med. Pepperoni pizza",
                                "Med. Supreme pizza"};

        string[] strBreads = {"Choose a bread type", // bread type array
                                 "White",
                                 "Pumpernickel",
                                 "Rye",
                                 "Sourdough",
                                 "Multigrain"};

        string[] strCrusts = {"Choose a crust type", // crust type array
                                 "Original",
                                 "Pan",
                                 "Thin",
                                 "Wheat"};

        string[] strEmpty = { "Choose a food item" }; // when it is empty

        string[] strIngredients = { "flour", "yeast", "sugar", "oil", "ham", "turkey", "scheese", "lettuce", "tomato", "bacon", "pickles", "mayo", "mustard", "pepperoni", "sauce", "gcheese", "salt", "pepper" }; // ingredients array

        decimal[] decNewIngredientInventory = new decimal[18]; // place holder array

        decimal[] decIngredientsInventory = { 200m, 50m, 30m, 25m, 10m, 10m, 20m, 14m, 14m, 10m, 20m, 15m, 12m, 20m, 60m, 25m, 10m, 10m }; // total inventories array

        decimal[,] decIngredientsNeeded = {{1m, 0.5m, 0.03m, 0.05m, 0.1m, 0m, 0.1m, 0.25m, 0.25m, 0m, 0.02m, 0.02m, 0.02m, 0m, 0m, 0m, 0.01m, 0.01m},
                                    {1m, 0.5m, 0.03m, 0.05m, 0m, 0.1m, 0.1m, 0.25m, 0.25m, 0m, 0.02m, 0.02m, 0.02m, 0m, 0m, 0m, 0.01m, 0.01m}, 
                                    {1m, 0.5m, 0.03m, 0.05m, 0m, 0m, 0m, 0.3m, 0.3m, 0.1m, 0m, 0.02m, 0.02m, 0m, 0m, 0m, 0.01m, 0.01m}, 
                                    {3m, 2m, 0.5m, 0.1m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 1m, 0.3m, 0.02m, 0.02m}, 
                                    {3m, 2m, 0.5m, 0.1m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0.3m, 1m, 0.2m, 0.02m, 0.02m}, 
                                    {3m, 2m, 0.5m, 0.1m, 0.1m, 0.1m, 0m, 0m, 0.3m, 0.1m, 0m, 0m, 0m, 0.3m, 1m, 0.2m, 0.02m, 0.02m},}; 

        decimal decBeforeTax = 0m;
        decimal decTaxRate = 0.0825m;
        decimal decTax = 0m;
        decimal decTotalPrice = 0m;

        decimal decSandwichPrice = 5m;
        decimal decPizzaPrice = 9.5m;


        /// <summary>
        /// when user clicks view inventory, an instance of the FRMInventory is made which is what allows us to initialize the place holder arrays with the updated values in this class
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNVeiwInventory_Click(object sender, EventArgs e)
        {

            FRMInventory NewInventoryForm = new FRMInventory(); // creates a new instance of the FRMInventory class
            NewInventoryForm.ArrayUpdatedInventory = decIngredientsInventory; //sends the quantities of the Ingredients Inventory to the new array intialized in the FRMInventory class
            NewInventoryForm.UpdatedInventoryFoodItems = strIngredients; //sends the items of the string ingredients array to the new array intialized in the FRMInventory class

            NewInventoryForm.Show(); //shows form
        }

        /// <summary>
        /// decrease inventories depending on the quantity provided by user by using a for loop
        /// </summary>
        /// <param name="intQuantity"></param>
        private void UpdateInventory(int intQuantity)
        {
            for (int i = 0; i < decNewIngredientInventory.Length; i++)
            {
                decNewIngredientInventory[i] += (decIngredientsNeeded[CBXFoodItem.SelectedIndex - 1, i]) * intQuantity; // math to decrease inventories
            }
        }


        /// <summary>
        /// resets all fields and initializes default values in the form.
        /// </summary>
        private void ClearAll()
        {
            CBXFoodItem.Items.Clear();

            foreach (string strFoodItem in strFoodItems)
                CBXFoodItem.Items.Add(strFoodItem);

            CBXFoodItem.SelectedIndex = 0;

            foreach (string strNothing in strEmpty)
                CBXBreadCrust.Items.Add(strNothing);

            CBXBreadCrust.SelectedIndex = 0;

            RDOCarryout.Checked = true;

            GBXDeliveryInformation.Enabled = false;

            TXTDeliveryName.Clear();
            TXTDeliveryStreet.Clear();
            TXTDeliveryCity.Clear();
            TXTDeliveryState.Clear();
            TXTDeliveryZip.Clear();
            TXTDeliveryPhone.Clear();
            TXTDeliverySubdivision.Clear();


            TXTQuantity.Clear();
            TXTSubtotal.Clear();
            TXTTax.Clear();
            TXTOrderTotal.Clear();
            

            decBeforeTax = 0m;
            decTax = 0m;
            decTotalPrice = 0m;

            TXTSubtotal.Text = decBeforeTax.ToString("c");
            TXTTax.Text = decTax.ToString("c");
            TXTOrderTotal.Text = decTotalPrice.ToString("c");

            LBXOrderSummary.Items.Clear();
            decNewIngredientInventory = new decimal[18]; // new array is initialized when clear is clicked, so all inventories reset

            PBXFoodImage.Image = null;
        }

        /// <summary>
        /// initializes the form when it loads.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMOrder_Load(object sender, EventArgs e)
        {
            ClearAll();
        }

        /// <summary>`
        /// exit form when clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// updates bread/crust options and food image based on the selected food item.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CBXFoodItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CBXFoodItem.SelectedIndex == 0)
            {
                CBXBreadCrust.Items.Clear();

                foreach (string strNoItemSelected in strEmpty)
                    CBXBreadCrust.Items.Add(strNoItemSelected);

                CBXBreadCrust.SelectedIndex = 0;

                PBXFoodImage.Image = null;
            }
            else if (CBXFoodItem.SelectedIndex >= 4)
            {
                CBXBreadCrust.Items.Clear();

                foreach (string strCrustType in strCrusts)
                    CBXBreadCrust.Items.Add(strCrustType);

                CBXBreadCrust.SelectedIndex = 0;


                PBXFoodImage.Image = Properties.Resources.pizza;
            }
            else
            {
                CBXBreadCrust.Items.Clear();

                foreach (string strBreadType in strBreads)
                    CBXBreadCrust.Items.Add(strBreadType);

                CBXBreadCrust.SelectedIndex = 0;

                PBXFoodImage.Image = Properties.Resources.deli;
            }
        }

        private void BTNAddItem_Click(object sender, EventArgs e)
        {
            if (IsValidData()) // Validate input data before proceeding.
            {
                decimal decPrice = 0m;
                decimal decSubtotal = 0m;

                // Add the formatted order string to the ListBox and calculate price/subtotal.
                LBXOrderSummary.Items.Add(AddNewItems(ref decPrice, ref decSubtotal)); // Add to ListBox.

                int intQuantity = Convert.ToInt32(TXTQuantity.Text); // Convert user input to integer.
                UpdateInventory(intQuantity); // Update inventory with user-inputted quantity.

                // Update subtotal, tax, and total price.
                decBeforeTax += decSubtotal; // Increment by the new subtotal.
                decTax = decBeforeTax * decTaxRate; // Calculate tax based on total before tax.
                decTotalPrice = decBeforeTax + decTax; // Correct the total price calculation.

                // Update the UI with formatted values.
                TXTSubtotal.Text = decBeforeTax.ToString("c");
                TXTTax.Text = decTax.ToString("c");
                TXTOrderTotal.Text = decTotalPrice.ToString("c");

                // Reset input fields.
                CBXFoodItem.SelectedIndex = 0;
                TXTQuantity.Clear();
            }
        }

        /// <summary>
        /// Adds a new order item to the summary and calculates price and subtotal.
        /// </summary>
        /// <returns>A formatted order summary string.</returns>
        private string AddNewItems(ref decimal decPrice, ref decimal decSubtotal)
        {
            // Determine the price based on the selected item type (e.g., sandwich or pizza).
            if (CBXFoodItem.SelectedIndex >= 4) // Check if the user selected a pizza item.
            {
                decPrice = decPizzaPrice;
            }
            else
            {
                decPrice = decSandwichPrice;
            }

            // Convert the quantity from the text box to a decimal.
            decimal decQuantity = Convert.ToDecimal(TXTQuantity.Text);

            // Calculate the subtotal for the current item.
            decSubtotal = decQuantity * decPrice;

            // Construct a formatted string to display in the order summary ListBox.
            string strOrder = CBXBreadCrust.Text.ToString() + " " + CBXFoodItem.Text.ToString() + ", " + TXTQuantity.Text
                + " @ " + decPrice.ToString("c") + ", total: " + decSubtotal.ToString("c");

            return strOrder; // Return the formatted string.
        }


        /// <summary>
        /// Enables or disables the delivery information group box based on the selected radio button.
        /// Makes the corresponding group of textboxes readonly when the other button is selected.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RDODelivery_CheckedChanged(object sender, EventArgs e)
        {
            if (RDODelivery.Checked == true) // if delivery is selected, then delivery information will be enabled
            {
                GBXDeliveryInformation.Enabled = true;

                // Enable the delivery fields and disable the carryout fields
                SetCarryoutFieldsReadonly(true); // Make carryout fields readonly

                // Copy customer information to delivery fields
                TXTDeliveryName.Text = TXTCustomerName.Text;
                TXTDeliveryStreet.Text = TXTCustomerStreet.Text;
                TXTDeliveryCity.Text = TXTCustomerCity.Text;
                TXTDeliveryState.Text = TXTCustomerState.Text;
                TXTDeliveryZip.Text = TXTCustomerZip.Text;
                TXTDeliveryPhone.Text = TXTCustomerPhone.Text;
                TXTDeliverySubdivision.Text = TXTCustomerSubdivision.Text;

                TXTDeliveryName.Focus();  // sets focus to delivery if the delivery button is clicked, so user can enter immediately
            }
            else // if carryout is selected
            {
                GBXDeliveryInformation.Enabled = false; // Disable the delivery information box
                SetCarryoutFieldsReadonly(false); // Make carryout fields editable
            }
        }

        /// <summary>
        /// Sets the carryout fields as readonly or not.
        /// </summary>
        /// <param name="isReadonly"></param>
        private void SetCarryoutFieldsReadonly(bool isReadonly)
        {
            TXTCustomerName.ReadOnly = isReadonly;
            TXTCustomerStreet.ReadOnly = isReadonly;
            TXTCustomerCity.ReadOnly = isReadonly;
            TXTCustomerState.ReadOnly = isReadonly;
            TXTCustomerZip.ReadOnly = isReadonly;
            TXTCustomerPhone.ReadOnly = isReadonly;
            TXTCustomerSubdivision.ReadOnly = isReadonly;
        }


        /// <summary>
        /// Processes the order by validating inputs and displaying a confirmation message.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNProcessOrder_Click(object sender, EventArgs e)
        {
            if (IsValidOrder())
            {
                MessageBox.Show("Your order is being processed. Thank you!", "Order Complete");
                for (int i = 0; i < decNewIngredientInventory.Length; i++) // if process order is succesful, then decrement the total ingredients accordingly
                {
                    decIngredientsInventory[i] -= decNewIngredientInventory[i]; 
                }

                ClearAll(); // clear
            }
        }


        /// <summary>
        /// clears the whole form when clear is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNClearForm_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        /// <summary>
        /// when the user wants to close the form, a popup will show confirming the request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMOrder_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to close?", "Closing",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {

                e.Cancel = true;

            }
        }

        #region Validation
        /// <summary>
        /// validation classes which are called from the validator class checking if all data is valid
        /// </summary>
        /// <returns></returns>
        private bool IsValidData()
        {
            string strErrorMessage = "";


            strErrorMessage += Validator.IsSelected(CBXFoodItem.SelectedIndex);
            strErrorMessage += Validator.IsSelected(CBXBreadCrust.SelectedIndex);
            strErrorMessage += Validator.IsValidQuantity(TXTQuantity.Text);

            if (strErrorMessage != "")
            {
                MessageBox.Show(strErrorMessage);
                return false;
            }
            else
            {
                return true;
            }
        }

        
        /// <summary>
        /// calls from validator class and checks if all user entry is persent and if valid
        /// </summary>
        /// <returns></returns>
        private bool IsValidOrder()
        {
            string strErrorMessage = "";

            strErrorMessage += Validator.IsValidOrder(LBXOrderSummary.Items.Count);
            strErrorMessage += Validator.IsValidCity(TXTDeliveryCity.Text, TXTDeliveryState.Text, RDOCarryout.Checked, RDODelivery.Checked);

            if (RDOCarryout.Checked)
            {
                strErrorMessage += Validator.IsPresentOrder(TXTCustomerName.Text, TXTCustomerStreet.Text, TXTCustomerCity.Text, TXTCustomerState.Text, TXTCustomerZip.Text, TXTCustomerPhone.Text, TXTCustomerSubdivision.Text);
            }
            else if (RDODelivery.Checked)
                strErrorMessage += Validator.IsPresentOrder(TXTDeliveryName.Text, TXTDeliveryStreet.Text, TXTDeliveryCity.Text, TXTDeliveryState.Text, TXTDeliveryZip.Text, TXTDeliveryPhone.Text, TXTDeliverySubdivision.Text);

            if (strErrorMessage != "")
            {
                MessageBox.Show(strErrorMessage);
                return false;
            }
            else
            {
                return true;
            }
        }


        #endregion

        private void BTNViewVendors_Click(object sender, EventArgs e)
        {
            FRMVendor NewVendorForm = new FRMVendor();
            NewVendorForm.ShowDialog();
        }
    }

}