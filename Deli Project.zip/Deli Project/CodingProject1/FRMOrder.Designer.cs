﻿namespace CodingProject1
{
    partial class FRMOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TXTCustomerName = new System.Windows.Forms.TextBox();
            this.TXTCustomerStreet = new System.Windows.Forms.TextBox();
            this.TXTCustomerCity = new System.Windows.Forms.TextBox();
            this.TXTCustomerState = new System.Windows.Forms.TextBox();
            this.TXTCustomerZip = new System.Windows.Forms.TextBox();
            this.TXTCustomerPhone = new System.Windows.Forms.TextBox();
            this.TXTCustomerSubdivision = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.GBXCustomerInformation = new System.Windows.Forms.GroupBox();
            this.GBXDeliveryInformation = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TXTDeliveryName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.TXTDeliveryStreet = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.TXTDeliveryCity = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.TXTDeliveryState = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.TXTDeliveryZip = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.TXTDeliveryPhone = new System.Windows.Forms.TextBox();
            this.TXTDeliverySubdivision = new System.Windows.Forms.TextBox();
            this.CBXFoodItem = new System.Windows.Forms.ComboBox();
            this.CBXBreadCrust = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.LBXOrderSummary = new System.Windows.Forms.ListBox();
            this.label17 = new System.Windows.Forms.Label();
            this.BTNAddItem = new System.Windows.Forms.Button();
            this.BTNProcessOrder = new System.Windows.Forms.Button();
            this.BTNClear = new System.Windows.Forms.Button();
            this.BTNClose = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.GBXOrderType = new System.Windows.Forms.GroupBox();
            this.RDOCarryout = new System.Windows.Forms.RadioButton();
            this.RDODelivery = new System.Windows.Forms.RadioButton();
            this.TXTQuantity = new System.Windows.Forms.TextBox();
            this.TXTOrderTotal = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.PBXFoodImage = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.TXTTax = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.TXTSubtotal = new System.Windows.Forms.TextBox();
            this.BTNVeiwInventory = new System.Windows.Forms.Button();
            this.BTNViewVendors = new System.Windows.Forms.Button();
            this.GBXCustomerInformation.SuspendLayout();
            this.GBXDeliveryInformation.SuspendLayout();
            this.GBXOrderType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBXFoodImage)).BeginInit();
            this.SuspendLayout();
            // 
            // TXTCustomerName
            // 
            this.TXTCustomerName.Location = new System.Drawing.Point(109, 32);
            this.TXTCustomerName.Name = "TXTCustomerName";
            this.TXTCustomerName.Size = new System.Drawing.Size(205, 20);
            this.TXTCustomerName.TabIndex = 0;
            // 
            // TXTCustomerStreet
            // 
            this.TXTCustomerStreet.Location = new System.Drawing.Point(62, 69);
            this.TXTCustomerStreet.Name = "TXTCustomerStreet";
            this.TXTCustomerStreet.Size = new System.Drawing.Size(252, 20);
            this.TXTCustomerStreet.TabIndex = 1;
            // 
            // TXTCustomerCity
            // 
            this.TXTCustomerCity.Location = new System.Drawing.Point(62, 149);
            this.TXTCustomerCity.Name = "TXTCustomerCity";
            this.TXTCustomerCity.Size = new System.Drawing.Size(100, 20);
            this.TXTCustomerCity.TabIndex = 3;
            // 
            // TXTCustomerState
            // 
            this.TXTCustomerState.Location = new System.Drawing.Point(214, 149);
            this.TXTCustomerState.Name = "TXTCustomerState";
            this.TXTCustomerState.Size = new System.Drawing.Size(100, 20);
            this.TXTCustomerState.TabIndex = 4;
            // 
            // TXTCustomerZip
            // 
            this.TXTCustomerZip.Location = new System.Drawing.Point(62, 198);
            this.TXTCustomerZip.Name = "TXTCustomerZip";
            this.TXTCustomerZip.Size = new System.Drawing.Size(100, 20);
            this.TXTCustomerZip.TabIndex = 5;
            // 
            // TXTCustomerPhone
            // 
            this.TXTCustomerPhone.Location = new System.Drawing.Point(214, 198);
            this.TXTCustomerPhone.Name = "TXTCustomerPhone";
            this.TXTCustomerPhone.Size = new System.Drawing.Size(100, 20);
            this.TXTCustomerPhone.TabIndex = 6;
            // 
            // TXTCustomerSubdivision
            // 
            this.TXTCustomerSubdivision.Location = new System.Drawing.Point(88, 110);
            this.TXTCustomerSubdivision.Name = "TXTCustomerSubdivision";
            this.TXTCustomerSubdivision.Size = new System.Drawing.Size(226, 20);
            this.TXTCustomerSubdivision.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Customer Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Street:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "City:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(178, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "State:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Zip:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(172, 205);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Phone:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Subdivision:";
            // 
            // GBXCustomerInformation
            // 
            this.GBXCustomerInformation.Controls.Add(this.label1);
            this.GBXCustomerInformation.Controls.Add(this.label7);
            this.GBXCustomerInformation.Controls.Add(this.TXTCustomerName);
            this.GBXCustomerInformation.Controls.Add(this.label6);
            this.GBXCustomerInformation.Controls.Add(this.TXTCustomerStreet);
            this.GBXCustomerInformation.Controls.Add(this.label5);
            this.GBXCustomerInformation.Controls.Add(this.TXTCustomerCity);
            this.GBXCustomerInformation.Controls.Add(this.label4);
            this.GBXCustomerInformation.Controls.Add(this.TXTCustomerState);
            this.GBXCustomerInformation.Controls.Add(this.label3);
            this.GBXCustomerInformation.Controls.Add(this.TXTCustomerZip);
            this.GBXCustomerInformation.Controls.Add(this.label2);
            this.GBXCustomerInformation.Controls.Add(this.TXTCustomerPhone);
            this.GBXCustomerInformation.Controls.Add(this.TXTCustomerSubdivision);
            this.GBXCustomerInformation.Location = new System.Drawing.Point(12, 118);
            this.GBXCustomerInformation.Name = "GBXCustomerInformation";
            this.GBXCustomerInformation.Size = new System.Drawing.Size(355, 243);
            this.GBXCustomerInformation.TabIndex = 14;
            this.GBXCustomerInformation.TabStop = false;
            this.GBXCustomerInformation.Text = "Customer Information";
            // 
            // GBXDeliveryInformation
            // 
            this.GBXDeliveryInformation.Controls.Add(this.label8);
            this.GBXDeliveryInformation.Controls.Add(this.label9);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryName);
            this.GBXDeliveryInformation.Controls.Add(this.label10);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryStreet);
            this.GBXDeliveryInformation.Controls.Add(this.label11);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryCity);
            this.GBXDeliveryInformation.Controls.Add(this.label12);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryState);
            this.GBXDeliveryInformation.Controls.Add(this.label13);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryZip);
            this.GBXDeliveryInformation.Controls.Add(this.label14);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliveryPhone);
            this.GBXDeliveryInformation.Controls.Add(this.TXTDeliverySubdivision);
            this.GBXDeliveryInformation.Enabled = false;
            this.GBXDeliveryInformation.Location = new System.Drawing.Point(405, 118);
            this.GBXDeliveryInformation.Name = "GBXDeliveryInformation";
            this.GBXDeliveryInformation.Size = new System.Drawing.Size(375, 243);
            this.GBXDeliveryInformation.TabIndex = 15;
            this.GBXDeliveryInformation.TabStop = false;
            this.GBXDeliveryInformation.Text = "Delivery Information";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Customer Name:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Subdivision:";
            // 
            // TXTDeliveryName
            // 
            this.TXTDeliveryName.Location = new System.Drawing.Point(110, 31);
            this.TXTDeliveryName.Name = "TXTDeliveryName";
            this.TXTDeliveryName.Size = new System.Drawing.Size(205, 20);
            this.TXTDeliveryName.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(173, 204);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "Phone:";
            // 
            // TXTDeliveryStreet
            // 
            this.TXTDeliveryStreet.Location = new System.Drawing.Point(63, 68);
            this.TXTDeliveryStreet.Name = "TXTDeliveryStreet";
            this.TXTDeliveryStreet.Size = new System.Drawing.Size(252, 20);
            this.TXTDeliveryStreet.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 197);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 13);
            this.label11.TabIndex = 25;
            this.label11.Text = "Zip:";
            // 
            // TXTDeliveryCity
            // 
            this.TXTDeliveryCity.Location = new System.Drawing.Point(63, 148);
            this.TXTDeliveryCity.Name = "TXTDeliveryCity";
            this.TXTDeliveryCity.Size = new System.Drawing.Size(100, 20);
            this.TXTDeliveryCity.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(179, 151);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "State:";
            // 
            // TXTDeliveryState
            // 
            this.TXTDeliveryState.Location = new System.Drawing.Point(215, 148);
            this.TXTDeliveryState.Name = "TXTDeliveryState";
            this.TXTDeliveryState.Size = new System.Drawing.Size(100, 20);
            this.TXTDeliveryState.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 151);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(27, 13);
            this.label13.TabIndex = 23;
            this.label13.Text = "City:";
            // 
            // TXTDeliveryZip
            // 
            this.TXTDeliveryZip.Location = new System.Drawing.Point(63, 197);
            this.TXTDeliveryZip.Name = "TXTDeliveryZip";
            this.TXTDeliveryZip.Size = new System.Drawing.Size(100, 20);
            this.TXTDeliveryZip.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 71);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 13);
            this.label14.TabIndex = 22;
            this.label14.Text = "Street:";
            // 
            // TXTDeliveryPhone
            // 
            this.TXTDeliveryPhone.Location = new System.Drawing.Point(215, 197);
            this.TXTDeliveryPhone.Name = "TXTDeliveryPhone";
            this.TXTDeliveryPhone.Size = new System.Drawing.Size(100, 20);
            this.TXTDeliveryPhone.TabIndex = 20;
            // 
            // TXTDeliverySubdivision
            // 
            this.TXTDeliverySubdivision.Location = new System.Drawing.Point(89, 109);
            this.TXTDeliverySubdivision.Name = "TXTDeliverySubdivision";
            this.TXTDeliverySubdivision.Size = new System.Drawing.Size(226, 20);
            this.TXTDeliverySubdivision.TabIndex = 16;
            // 
            // CBXFoodItem
            // 
            this.CBXFoodItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBXFoodItem.FormattingEnabled = true;
            this.CBXFoodItem.Items.AddRange(new object[] {
            "Ham & Swiss sandwich",
            "Turkey & Provolone sandwich",
            "BLT sandwich",
            "Medium cheese pizza",
            "Medium pepperoni pizza",
            "Medium supreme pizza"});
            this.CBXFoodItem.Location = new System.Drawing.Point(117, 389);
            this.CBXFoodItem.Name = "CBXFoodItem";
            this.CBXFoodItem.Size = new System.Drawing.Size(183, 21);
            this.CBXFoodItem.TabIndex = 16;
            this.CBXFoodItem.SelectedIndexChanged += new System.EventHandler(this.CBXFoodItem_SelectedIndexChanged);
            // 
            // CBXBreadCrust
            // 
            this.CBXBreadCrust.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBXBreadCrust.FormattingEnabled = true;
            this.CBXBreadCrust.Location = new System.Drawing.Point(117, 430);
            this.CBXBreadCrust.Name = "CBXBreadCrust";
            this.CBXBreadCrust.Size = new System.Drawing.Size(183, 21);
            this.CBXBreadCrust.TabIndex = 17;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(30, 392);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "Food Item:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(30, 433);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 13);
            this.label16.TabIndex = 19;
            this.label16.Text = "Bread/Crust:";
            // 
            // LBXOrderSummary
            // 
            this.LBXOrderSummary.FormattingEnabled = true;
            this.LBXOrderSummary.Location = new System.Drawing.Point(373, 422);
            this.LBXOrderSummary.Name = "LBXOrderSummary";
            this.LBXOrderSummary.Size = new System.Drawing.Size(407, 160);
            this.LBXOrderSummary.TabIndex = 20;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(370, 406);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 13);
            this.label17.TabIndex = 21;
            this.label17.Text = "Order Summary";
            // 
            // BTNAddItem
            // 
            this.BTNAddItem.Location = new System.Drawing.Point(33, 610);
            this.BTNAddItem.Name = "BTNAddItem";
            this.BTNAddItem.Size = new System.Drawing.Size(121, 23);
            this.BTNAddItem.TabIndex = 22;
            this.BTNAddItem.Text = "Add Item";
            this.BTNAddItem.UseVisualStyleBackColor = true;
            this.BTNAddItem.Click += new System.EventHandler(this.BTNAddItem_Click);
            // 
            // BTNProcessOrder
            // 
            this.BTNProcessOrder.Location = new System.Drawing.Point(179, 610);
            this.BTNProcessOrder.Name = "BTNProcessOrder";
            this.BTNProcessOrder.Size = new System.Drawing.Size(121, 23);
            this.BTNProcessOrder.TabIndex = 23;
            this.BTNProcessOrder.Text = "Process Order";
            this.BTNProcessOrder.UseVisualStyleBackColor = true;
            this.BTNProcessOrder.Click += new System.EventHandler(this.BTNProcessOrder_Click);
            // 
            // BTNClear
            // 
            this.BTNClear.Location = new System.Drawing.Point(33, 671);
            this.BTNClear.Name = "BTNClear";
            this.BTNClear.Size = new System.Drawing.Size(121, 23);
            this.BTNClear.TabIndex = 24;
            this.BTNClear.Text = "Clear";
            this.BTNClear.UseVisualStyleBackColor = true;
            this.BTNClear.Click += new System.EventHandler(this.BTNClearForm_Click);
            // 
            // BTNClose
            // 
            this.BTNClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BTNClose.Location = new System.Drawing.Point(179, 671);
            this.BTNClose.Name = "BTNClose";
            this.BTNClose.Size = new System.Drawing.Size(121, 23);
            this.BTNClose.TabIndex = 25;
            this.BTNClose.Text = "Close";
            this.BTNClose.UseVisualStyleBackColor = true;
            this.BTNClose.Click += new System.EventHandler(this.BTNExit_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(580, 396);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 27;
            // 
            // GBXOrderType
            // 
            this.GBXOrderType.Controls.Add(this.RDOCarryout);
            this.GBXOrderType.Controls.Add(this.RDODelivery);
            this.GBXOrderType.Location = new System.Drawing.Point(12, 12);
            this.GBXOrderType.Name = "GBXOrderType";
            this.GBXOrderType.Size = new System.Drawing.Size(200, 100);
            this.GBXOrderType.TabIndex = 30;
            this.GBXOrderType.TabStop = false;
            this.GBXOrderType.Text = "Order Type";
            // 
            // RDOCarryout
            // 
            this.RDOCarryout.AutoSize = true;
            this.RDOCarryout.Location = new System.Drawing.Point(109, 43);
            this.RDOCarryout.Name = "RDOCarryout";
            this.RDOCarryout.Size = new System.Drawing.Size(64, 17);
            this.RDOCarryout.TabIndex = 35;
            this.RDOCarryout.TabStop = true;
            this.RDOCarryout.Text = "Carryout";
            this.RDOCarryout.UseVisualStyleBackColor = true;
            // 
            // RDODelivery
            // 
            this.RDODelivery.AutoSize = true;
            this.RDODelivery.Location = new System.Drawing.Point(14, 43);
            this.RDODelivery.Name = "RDODelivery";
            this.RDODelivery.Size = new System.Drawing.Size(63, 17);
            this.RDODelivery.TabIndex = 30;
            this.RDODelivery.TabStop = true;
            this.RDODelivery.Text = "Delivery";
            this.RDODelivery.UseVisualStyleBackColor = true;
            this.RDODelivery.CheckedChanged += new System.EventHandler(this.RDODelivery_CheckedChanged);
            // 
            // TXTQuantity
            // 
            this.TXTQuantity.Location = new System.Drawing.Point(117, 470);
            this.TXTQuantity.Name = "TXTQuantity";
            this.TXTQuantity.Size = new System.Drawing.Size(100, 20);
            this.TXTQuantity.TabIndex = 31;
            // 
            // TXTOrderTotal
            // 
            this.TXTOrderTotal.Location = new System.Drawing.Point(117, 562);
            this.TXTOrderTotal.Name = "TXTOrderTotal";
            this.TXTOrderTotal.ReadOnly = true;
            this.TXTOrderTotal.Size = new System.Drawing.Size(100, 20);
            this.TXTOrderTotal.TabIndex = 32;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(30, 473);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 13);
            this.label18.TabIndex = 28;
            this.label18.Text = "Quantity:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(30, 565);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 13);
            this.label19.TabIndex = 33;
            this.label19.Text = "Order Total";
            // 
            // PBXFoodImage
            // 
            this.PBXFoodImage.Location = new System.Drawing.Point(235, 462);
            this.PBXFoodImage.Name = "PBXFoodImage";
            this.PBXFoodImage.Size = new System.Drawing.Size(121, 120);
            this.PBXFoodImage.TabIndex = 34;
            this.PBXFoodImage.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(30, 534);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(28, 13);
            this.label20.TabIndex = 36;
            this.label20.Text = "Tax:";
            // 
            // TXTTax
            // 
            this.TXTTax.Location = new System.Drawing.Point(117, 531);
            this.TXTTax.Name = "TXTTax";
            this.TXTTax.ReadOnly = true;
            this.TXTTax.Size = new System.Drawing.Size(100, 20);
            this.TXTTax.TabIndex = 35;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(30, 504);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 13);
            this.label21.TabIndex = 38;
            this.label21.Text = "Subtotal:";
            // 
            // TXTSubtotal
            // 
            this.TXTSubtotal.Location = new System.Drawing.Point(117, 501);
            this.TXTSubtotal.Name = "TXTSubtotal";
            this.TXTSubtotal.ReadOnly = true;
            this.TXTSubtotal.Size = new System.Drawing.Size(100, 20);
            this.TXTSubtotal.TabIndex = 37;
            // 
            // BTNVeiwInventory
            // 
            this.BTNVeiwInventory.Location = new System.Drawing.Point(670, 631);
            this.BTNVeiwInventory.Name = "BTNVeiwInventory";
            this.BTNVeiwInventory.Size = new System.Drawing.Size(110, 23);
            this.BTNVeiwInventory.TabIndex = 39;
            this.BTNVeiwInventory.Text = "View Inventory";
            this.BTNVeiwInventory.UseVisualStyleBackColor = true;
            this.BTNVeiwInventory.Click += new System.EventHandler(this.BTNVeiwInventory_Click);
            // 
            // BTNViewVendors
            // 
            this.BTNViewVendors.Location = new System.Drawing.Point(671, 671);
            this.BTNViewVendors.Name = "BTNViewVendors";
            this.BTNViewVendors.Size = new System.Drawing.Size(109, 23);
            this.BTNViewVendors.TabIndex = 40;
            this.BTNViewVendors.Text = "View Vendors";
            this.BTNViewVendors.UseVisualStyleBackColor = true;
            this.BTNViewVendors.Click += new System.EventHandler(this.BTNViewVendors_Click);
            // 
            // FRMOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.BTNClose;
            this.ClientSize = new System.Drawing.Size(826, 717);
            this.Controls.Add(this.BTNViewVendors);
            this.Controls.Add(this.BTNVeiwInventory);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.TXTSubtotal);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.TXTTax);
            this.Controls.Add(this.PBXFoodImage);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.TXTOrderTotal);
            this.Controls.Add(this.TXTQuantity);
            this.Controls.Add(this.GBXOrderType);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.BTNClose);
            this.Controls.Add(this.BTNClear);
            this.Controls.Add(this.BTNProcessOrder);
            this.Controls.Add(this.BTNAddItem);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.LBXOrderSummary);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.CBXBreadCrust);
            this.Controls.Add(this.CBXFoodItem);
            this.Controls.Add(this.GBXDeliveryInformation);
            this.Controls.Add(this.GBXCustomerInformation);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FRMOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kirby\'s Deli Order Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FRMOrder_FormClosing);
            this.Load += new System.EventHandler(this.FRMOrder_Load);
            this.GBXCustomerInformation.ResumeLayout(false);
            this.GBXCustomerInformation.PerformLayout();
            this.GBXDeliveryInformation.ResumeLayout(false);
            this.GBXDeliveryInformation.PerformLayout();
            this.GBXOrderType.ResumeLayout(false);
            this.GBXOrderType.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBXFoodImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TXTCustomerName;
        private System.Windows.Forms.TextBox TXTCustomerStreet;
        private System.Windows.Forms.TextBox TXTCustomerCity;
        private System.Windows.Forms.TextBox TXTCustomerState;
        private System.Windows.Forms.TextBox TXTCustomerZip;
        private System.Windows.Forms.TextBox TXTCustomerPhone;
        private System.Windows.Forms.TextBox TXTCustomerSubdivision;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox GBXCustomerInformation;
        private System.Windows.Forms.GroupBox GBXDeliveryInformation;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TXTDeliveryName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox TXTDeliveryStreet;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox TXTDeliveryCity;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TXTDeliveryState;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TXTDeliveryZip;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TXTDeliveryPhone;
        private System.Windows.Forms.TextBox TXTDeliverySubdivision;
        private System.Windows.Forms.ComboBox CBXFoodItem;
        private System.Windows.Forms.ComboBox CBXBreadCrust;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ListBox LBXOrderSummary;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button BTNAddItem;
        private System.Windows.Forms.Button BTNProcessOrder;
        private System.Windows.Forms.Button BTNClear;
        private System.Windows.Forms.Button BTNClose;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox GBXOrderType;
        private System.Windows.Forms.TextBox TXTQuantity;
        private System.Windows.Forms.TextBox TXTOrderTotal;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox PBXFoodImage;
        private System.Windows.Forms.RadioButton RDODelivery;
        private System.Windows.Forms.RadioButton RDOCarryout;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox TXTTax;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox TXTSubtotal;
        private System.Windows.Forms.Button BTNVeiwInventory;
        private System.Windows.Forms.Button BTNViewVendors;
    }
}

