﻿using ISYS250HW;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodingProject1
{
    public partial class FRMVendor : Form
    {
        public FRMVendor()
        {
            InitializeComponent();
        }

        private List<Vendor> lstVendors = null; //list of vendors
        private int intSelectedIndex = 0; //sets index of the first vendor shown
        private bool blnHasUnsavedChanges = false; //helps track unsaved changes

        /// <summary>
        /// When the form loads, the vendor data is loaded ito the list, the discounts are added to the combobox, 
        /// the textboxes are filled with the first vendor's data, and the save button is disabled.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMVendor_Load(object sender, EventArgs e)
        {
            lstVendors = VendorDB.GetVendors(); //vendor data is loaded into the list

            //adds the discounts to the combobox
            CBXDefaultDiscount.Items.Add(10); 
            CBXDefaultDiscount.Items.Add(15);
            CBXDefaultDiscount.Items.Add(20);

            BTNSave.Enabled = false; //disables the save button

            FillTextboxes(); //fills textboxes

            this.Text = "Vendor"; //makes sure the form name is loaded correctly
        }

        /// <summary>
        /// this method fills the textboxes with the correct vendor data according to the selected index
        /// </summary>
        private void FillTextboxes()
        {
            
            Vendor vendor = lstVendors[intSelectedIndex]; //gets the vendor data corresponding to the selected index

            //fills the textboxes with the vendor data
            TXTVendor.Text = vendor.Name;
            TXTAddress.Text = vendor.Address;
            TXTCity.Text = vendor.City;
            TXTState.Text = vendor.State;
            TXTZip.Text = vendor.Zip;
            TXTPhone.Text = vendor.Phone;
            TXTSales.Text = vendor.YTD.ToString();
            TXTComment.Text = vendor.Comment;
            TXTContact.Text = vendor.Contact;
            CBXDefaultDiscount.SelectedItem = vendor.DefaultDiscount; //sets the discount in the combobox
            

            blnHasUnsavedChanges = false; //no more unsaved changed
            BTNSave.Enabled = false; //disabled save button

            this.Text = "Vendor"; //ensures form name stays as Vendor
        }

        /// <summary>
        /// when unsaved changes are present and the user wants to close or switch vendors, a dialogue box appears
        /// </summary>
        /// <returns></returns>
        private bool UnsavedChanges()
        {
            if (blnHasUnsavedChanges) //detects unsaved changes
            {
                //dialogue box appears 
                DialogResult result = MessageBox.Show(
                    "This form contains unsaved data. Do you want to save?",
                    "Unsaved Changes",
                    MessageBoxButtons.YesNoCancel,
                    MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    SaveChanges();
                    return true; //proceed after saving
                }
                else if (result == DialogResult.No)
                {
                    return true; //proceed without saving
                }
                else
                {
                    return false; //cancel navigation
                }
            }

            return true; //no changes, safe to proceed
        }

        /// <summary>
        /// When the user wants to save changes, the textboxes and combobox are updated
        /// </summary>
        private void SaveChanges()
        {
            if (!IsValidFields()) return; //stops saving if validation fails

            Vendor currentVendor = lstVendors[intSelectedIndex];

            //updates the current vendor with changes from the form
        
            currentVendor.Name = TXTVendor.Text;
            currentVendor.Address = TXTAddress.Text;
            currentVendor.City = TXTCity.Text;
            currentVendor.State = TXTState.Text;
            currentVendor.Zip = TXTZip.Text;
            currentVendor.Phone = (TXTPhone.Text);
            currentVendor.YTD = decimal.Parse(TXTSales.Text);
            currentVendor.Comment = TXTComment.Text;
            currentVendor.Contact = TXTContact.Text;
            currentVendor.DefaultDiscount = (int)decimal.Parse(CBXDefaultDiscount.Text);

            //saves the updated list back to the XML file
            VendorDB.SaveVendors(lstVendors);

            //resets the unsaved changes flag
            blnHasUnsavedChanges = false;

            //changes the form name back
            this.Text = "Vendor";

            //disables save button after save
            BTNSave.Enabled = false; 

            //notifies the user
            MessageBox.Show("All changes have been saved successfully.", "Save Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// rotates the vendor information forwards using the selected index variable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNNextVendor_Click(object sender, EventArgs e)
        {
            if (!UnsavedChanges()) return; //stops navigation if user cancels

            intSelectedIndex++;
            if (intSelectedIndex >= lstVendors.Count)
                intSelectedIndex = 0; //moves to next vendor

            FillTextboxes(); //calls the filltextbox method
        }

        /// <summary>
        /// rotates the vendor information backwards using the selected index variable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNPreviousVendor_Click(object sender, EventArgs e)
        {
            if (!UnsavedChanges()) return; //stops navigation if user cancels

            intSelectedIndex--;
            if (intSelectedIndex < 0)
                intSelectedIndex = lstVendors.Count - 1; //moves to previous vendor

            FillTextboxes(); //calls the filltextbox method
        }

        /// <summary>
        /// closes the form when the exit button is pressed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNExit_Click(object sender, EventArgs e)
        {
            Close(); //closes the form
        }

        /// <summary>
        /// if there is unsaved chnages, as the form is closing, a dialogue box will pop up and ask the user if they want to save the changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMVendor_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (blnHasUnsavedChanges) //detects unsaved data
            {
                DialogResult result = MessageBox.Show("You have unsaved data. \nDo you want to save?", "Unsaved Data", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    if (IsValidFields()) SaveChanges();
                    else e.Cancel = true; //prevents closing if validation fails and form closes
                }
                else if (result == DialogResult.Cancel)
                {
                    e.Cancel = true; //prevent closing if user cancels
                }
                // if no, form closes without saving
            }
        }

       /// <summary>
       /// actions taken when either the textboxes or combobox changes
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
        private void Control_TextChanged(object sender, EventArgs e)
        {
            blnHasUnsavedChanges = true; //stores the fact that there are unsaved changes
            this.Text = "Vendor*"; //marks as unsaved
            BTNSave.Enabled = true; //enables the save button
        }

        /// <summary>
        /// detects if the combobox changes and calls the control_textchanged method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CBXDefaultDiscount_SelectedIndexChanged(object sender, EventArgs e)
        {
            Control_TextChanged(sender, e);//calls this method
        }

        /// <summary>
        /// detects if the textboxes change and calls the control_textchanged method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AllTextboxes_TextChanged(object sender, EventArgs e)
        {
            Control_TextChanged(sender, e); //calls this method
        }

        /// <summary>
        /// when the save button is pressed, the SaveChanges method is called which saves the changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNSave_Click(object sender, EventArgs e)
        {
            SaveChanges();//saves changes
        }

        #region Validation

        /// <summary>
        /// Validates the textboxes and returns the correlating error messages
        /// </summary>
        /// <returns></returns>
        private bool IsValidFields()
        {

            string strErrorMessage = ""; //sets the message variable

            //makes sure the textboxes are present
            strErrorMessage += Validator.IsPresentVendor(TXTVendor.Text, "Vendor");
            strErrorMessage += Validator.IsPresentVendor(TXTAddress.Text, "Address");
            strErrorMessage += Validator.IsPresentVendor(TXTCity.Text, "City");
            strErrorMessage += Validator.IsPresentVendor(TXTState.Text, "State");
            strErrorMessage += Validator.IsPresentVendor(TXTContact.Text, "Contact");
            strErrorMessage += Validator.IsPresentVendor(TXTZip.Text, "ZIP");
            strErrorMessage += Validator.IsPresentVendor(TXTPhone.Text, "Phone");
            strErrorMessage += Validator.IsPresentVendor(TXTSales.Text, "YTD Sales");

            //makes sure sales is in integer form
            strErrorMessage += Validator.IsInteger(TXTSales.Text, "YTD Sales");



            if (strErrorMessage != "") //if one more validation tests generated an error
            {
                MessageBox.Show(strErrorMessage);
                return false; //we did not validate
            }
            else
            {
                return true; // all our inputs validted without error
            }

        }
        #endregion
    }
}


